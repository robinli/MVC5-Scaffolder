﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : Page
{
    protected readonly MyDB _db = new MyDB();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ViewState["subitem"] = new List<OrderItem>() { new OrderItem() };
        }
    }

    // The return type can be changed to IEnumerable, however to support
    // paging and sorting, the following parameters must be added:
    //     int maximumRows
    //     int startRowIndex
    //     out int totalRowCount
    //     string sortByExpression
    public IQueryable GridView1_GetData()
    {
        return _db.Orders;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        var neworder = new Order();
        neworder.Address = "OrderAddress";
        neworder.OrderDate = DateTime.Now;
        neworder.OrderItems.Add( new OrderItem() { ProductName = "MyProdct", Qty = 1 } );
        _db.Orders.Add(neworder);
        _db.Entry(neworder).State = System.Data.Entity.EntityState.Added;
        _db.SaveChanges();
        this.GridView1.DataBind();

    }

    public void FormView1_InsertItem()
    {
        var grid = (GridView)this.FormView1.FindControl("GridView2");
        var list = (List<OrderItem>)ViewState["subitem"];
        for (int i = 0; i < grid.Rows.Count; i++)
        {
            TextBox inputProductName = (TextBox)grid.Rows[i].Cells[1].FindControl("ProductName");
            TextBox inputQty = (TextBox)grid.Rows[i].Cells[2].FindControl("Qty");
            var item = list[i];
            item.ProductName = inputProductName.Text;
            item.Qty = Convert.ToInt32(inputQty.Text);
        }

        var model = _db.Orders.Create();
        if (this.TryUpdateModel(model))
        {
            model.OrderItems = list;
            _db.Orders.Add(model);
            _db.SaveChanges();
            this.GridView1.DataBind();
        }
    }
    protected void FormView1_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        this.GridView1.DataBind();
    }

    // The id parameter name should match the DataKeyNames value set on the control
    public void GridView1_DeleteItem(int id)
    {
        _db.Orders.Remove(_db.Orders.Find(id));
        _db.SaveChanges();

    }
    protected void GridView2_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void GridView3_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void addrow_Click(object sender, EventArgs e)
    {
        var list = (List<OrderItem>)ViewState["subitem"];
        list.Add(new OrderItem());
        var grid=  (GridView)this.FormView1.FindControl("GridView2");
        for (int i = 0; i <grid.Rows.Count; i++)
        {
            TextBox inputProductName = (TextBox)grid.Rows[i].Cells[1].FindControl("ProductName");
            TextBox inputQty = (TextBox)grid.Rows[i].Cells[2].FindControl("Qty");
            var item = list[i];
            item.ProductName = inputProductName.Text;
            item.Qty = Convert.ToInt32(inputQty.Text);



            
          
        }

        ViewState["subitem"] = list;
        grid.DataBind();
        
    }
    protected void FormView1_ItemCreated(object sender, EventArgs e)
    {
        //ViewState["subitem"] = new List<OrderItem>() { new OrderItem() };
    }

    // The return type can be changed to IEnumerable, however to support
    // paging and sorting, the following parameters must be added:
    //     int maximumRows
    //     int startRowIndex
    //     out int totalRowCount
    //     string sortByExpression
    public IQueryable<OrderItem> GridView2_GetData()
    {
        var list=(List<OrderItem>)ViewState["subitem"];
        return list.AsQueryable();
    }
    public IQueryable<OrderItem> GridView3_GetData([System.Web.ModelBinding.Control("GridView1")] int? Id)
    {
        int count = _db.OrderItems.Where(n => n.Order_Id == Id).Count();
        return _db.OrderItems.Where(n => n.Order_Id == Id);
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.FormView1.ChangeMode(FormViewMode.Edit);
        var grid=(GridView) this.FormView1.FindControl("GridView3");
        if (grid!=null)
        grid.DataBind();
    }
    public  Order  FormView1_GetItem([System.Web.ModelBinding.Control("GridView1")] int? Id)
    {
        return _db.Orders.Where(n => n.Id == Id).First();
    }
}