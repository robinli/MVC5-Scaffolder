﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Order
/// </summary>
[Serializable]
public class Order
{
	public Order()
	{

        OrderItems = new HashSet<OrderItem>();
	}
    [Key]
    public int Id { get; set; }
    public DateTime OrderDate { get; set; }

    public string Address { get; set; }
    public virtual ICollection<OrderItem> OrderItems { get; set; }
}

[Serializable]
public class OrderItem
{
    [Key]
    public int Id { get; set; }
    public string ProductName { get; set; }
    public int Qty { get; set; }
    public int Order_Id { get; set; }
    [ForeignKey("Order_Id")]
    public virtual Order Order { get; set; }
}

public class MyDB : DbContext
{
    public DbSet<Order> Orders { get; set; }
    public DbSet<OrderItem> OrderItems { get; set; }
}